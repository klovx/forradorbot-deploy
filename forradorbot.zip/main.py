from flask import Flask
from threading import Thread
from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes

app = Flask(__name__)

@app.route('/')
def home():
    return "Bot está rodando!"

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "Bem-vindo ao ForradorBot! Use /ajuda para ver os comandos disponíveis."
    )

async def ajuda(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "Comandos disponíveis:\n"
        "/start – Inicia o bot\n"
        "/ajuda – Mostra esta mensagem\n"
        "/playerprops Tatum, Jokic – Mostra estatísticas de jogadores\n"
        "/pontos nome – Projeção de pontos\n"
        "/rebotes nome – Projeção de rebotes\n"
        "/assistencias nome – Projeção de assistências\n"
        "/aoVivo nome – Estatísticas ao vivo\n"
        "/multipla alvo 6.0 – Sugestão de múltiplas com odd alvo"
    )

def run_flask():
    app.run(host='0.0.0.0', port=8080)

def main():
    thread = Thread(target=run_flask)
    thread.start()

    TOKEN = "7567237226:AAHkFjebYMioDX_kBHJnA3YxgN9FzpNS8cI"
    
    application = Application.builder().token(TOKEN).build()
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("ajuda", ajuda))

    print("Bot iniciado...")
    application.run_polling()

if __name__ == "__main__":
    main()
